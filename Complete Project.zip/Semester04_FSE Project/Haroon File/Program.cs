using System;
using System.Windows.Forms;

public class Program
{
    public static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        //as loginform is actually has registration button too so we will got to loginform and can
        //register as well as login there
        Application.Run(new LoginForm());
        //or we can direct make registartion through dashbaord form too
        // Application.Run(new DashboardForm("Ali HASHIM", "ALI@gmail.com", "ALI_123"));
    }
}